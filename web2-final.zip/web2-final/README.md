# Web Design 2 - Final Project

## Terroir Tribeca Redesign

This is a project where I will be redesigning a Terroir Tribeca's website. It is a small local restaurant in New York most famous for its vast wine selection. The food items are also built around wine drinking such as cheeses, sandwiches, salads, steak, etc.

As nice as the restaurant is, to be blunt their website is major sensory overload and is overall really ugly. The fonts are strange and hard to read, and the design does not replicate the restaurant's atmosphere and style whatsoever. It is also difficult to navigate with unnecessary and unorganized information.

As for my part, I will redesign my own unofficial version of the website so it better replicates the business and makes the design simple and aesthetically pleasing. 